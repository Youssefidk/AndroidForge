package com.pocketpod.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 1001;
    private final ArrayList<Track> tracks = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout trackList;
    private TextView nowTitle, status, playButton;
    private EditText searchBox;
    private MediaPlayer player;
    private int currentIndex = -1;
    private boolean isPlaying = false;

    private static class Track {
        String title;
        String uri;
        Track(String title, String uri) { this.title = title; this.uri = uri; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("pocketpod", MODE_PRIVATE);
        loadTracks();
        buildUi();
        renderTracks("");
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        else t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.BLACK);
        b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(14));
        root.setBackgroundColor(Color.rgb(224, 226, 219));

        TextView logo = text("POCKETPOD  /  MUSIC", 21, Color.BLACK, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView line = text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", 13, Color.DKGRAY, false);
        line.setGravity(Gravity.CENTER);
        root.addView(line);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(15);
        searchBox.setTypeface(Typeface.MONOSPACE);
        searchBox.setHint("Search your library...");
        searchBox.setHintTextColor(Color.GRAY);
        searchBox.setTextColor(Color.BLACK);
        root.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(48)));

        Button importBtn = button("+  Import audio");
        root.addView(importBtn, new LinearLayout.LayoutParams(-1, dp(48)));

        status = text("LIBRARY", 13, Color.DKGRAY, true);
        status.setPadding(dp(4), dp(12), 0, dp(8));
        root.addView(status);

        ScrollView scroll = new ScrollView(this);
        trackList = new LinearLayout(this);
        trackList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(trackList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout playerPanel = new LinearLayout(this);
        playerPanel.setOrientation(LinearLayout.VERTICAL);
        playerPanel.setPadding(dp(10), dp(10), dp(10), dp(8));
        playerPanel.setBackgroundColor(Color.rgb(199, 202, 193));
        nowTitle = text("NOTHING PLAYING", 14, Color.BLACK, true);
        nowTitle.setGravity(Gravity.CENTER);
        playerPanel.addView(nowTitle, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        Button prev = button("|◀");
        playButton = text("▶", 22, Color.BLACK, true);
        playButton.setGravity(Gravity.CENTER);
        Button next = button("▶|");
        controls.addView(prev, new LinearLayout.LayoutParams(0, dp(52), 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(52), 1));
        controls.addView(next, new LinearLayout.LayoutParams(0, dp(52), 1));
        playerPanel.addView(controls);
        root.addView(playerPanel, new LinearLayout.LayoutParams(-1, dp(112)));
        setContentView(root);

        importBtn.setOnClickListener(v -> pickAudio());
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { renderTracks(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        playButton.setOnClickListener(v -> togglePlayback());
        prev.setOnClickListener(v -> playRelative(-1));
        next.setOnClickListener(v -> playRelative(1));
    }

    private void pickAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_AUDIO || resultCode != RESULT_OK || data == null) return;
        int added = 0;
        if (data.getClipData() != null) {
            for (int n = 0; n < data.getClipData().getItemCount(); n++) {
                Uri u = data.getClipData().getItemAt(n).getUri();
                if (addTrack(u, data.getFlags())) added++;
            }
        } else if (data.getData() != null) {
            if (addTrack(data.getData(), data.getFlags())) added++;
        }
        saveTracks();
        renderTracks(searchBox.getText().toString());
        Toast.makeText(this, "Imported " + added + " audio file(s)", Toast.LENGTH_SHORT).show();
    }

    private boolean addTrack(Uri u, int flags) {
        try { getContentResolver().takePersistableUriPermission(u, flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); }
        catch (Exception ignored) {}
        String name = "Unknown audio";
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0) name = c.getString(col);
            }
        } catch (Exception ignored) {}
        for (Track t : tracks) if (t.uri.equals(u.toString())) return false;
        tracks.add(new Track(name, u.toString()));
        return true;
    }

    private void renderTracks(String filter) {
        if (trackList == null) return;
        trackList.removeAllViews();
        int shown = 0;
        String q = filter == null ? "" : filter.toLowerCase(Locale.ROOT).trim();
        for (int i = 0; i < tracks.size(); i++) {
            final int index = i;
            Track t = tracks.get(i);
            if (!t.title.toLowerCase(Locale.ROOT).contains(q)) continue;
            TextView item = text(String.format(Locale.ROOT, "%02d   %s", shown + 1, t.title), 14, Color.BLACK, false);
            item.setPadding(dp(12), dp(14), dp(8), dp(14));
            item.setBackgroundColor(shown % 2 == 0 ? Color.rgb(240, 241, 235) : Color.rgb(212, 215, 207));
            item.setOnClickListener(v -> playTrack(index));
            trackList.addView(item, new LinearLayout.LayoutParams(-1, -2));
            View divider = new View(this);
            divider.setBackgroundColor(Color.rgb(155, 158, 150));
            trackList.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            shown++;
        }
        status.setText("LIBRARY  /  " + tracks.size() + " TRACK(S)");
        if (shown == 0) {
            TextView empty = text(tracks.isEmpty() ? "Your library is empty.\nTap Import audio to add music." : "No matching tracks.", 14, Color.DKGRAY, false);
            empty.setPadding(dp(10), dp(20), dp(10), dp(20));
            trackList.addView(empty);
        }
    }

    private void playTrack(int index) {
        if (index < 0 || index >= tracks.size()) return;
        releasePlayer();
        currentIndex = index;
        Track t = tracks.get(index);
        try {
            player = new MediaPlayer();
            player.setDataSource(this, Uri.parse(t.uri));
            player.setOnPreparedListener(mp -> {
                mp.start();
                isPlaying = true;
                playButton.setText("Ⅱ");
                nowTitle.setText(t.title);
            });
            player.setOnCompletionListener(mp -> playRelative(1));
            player.setOnErrorListener((mp, what, extra) -> {
                isPlaying = false;
                playButton.setText("▶");
                Toast.makeText(this, "Could not play this file format.", Toast.LENGTH_LONG).show();
                return true;
            });
            player.prepareAsync();
            nowTitle.setText("LOADING: " + t.title);
        } catch (IOException | IllegalStateException e) {
            Toast.makeText(this, "Could not open this audio file.", Toast.LENGTH_LONG).show();
            releasePlayer();
        }
    }

    private void togglePlayback() {
        if (player == null) {
            if (!tracks.isEmpty()) playTrack(currentIndex >= 0 ? currentIndex : 0);
            return;
        }
        try {
            if (player.isPlaying()) {
                player.pause();
                isPlaying = false;
                playButton.setText("▶");
            } else {
                player.start();
                isPlaying = true;
                playButton.setText("Ⅱ");
            }
        } catch (IllegalStateException ignored) {}
    }

    private void playRelative(int offset) {
        if (tracks.isEmpty()) return;
        int target = currentIndex < 0 ? 0 : (currentIndex + offset + tracks.size()) % tracks.size();
        playTrack(target);
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        isPlaying = false;
        if (playButton != null) playButton.setText("▶");
    }

    private void loadTracks() {
        try {
            JSONArray a = new JSONArray(prefs.getString("tracks", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                tracks.add(new Track(o.getString("title"), o.getString("uri")));
            }
        } catch (Exception ignored) {}
    }

    private void saveTracks() {
        JSONArray a = new JSONArray();
        try {
            for (Track t : tracks) {
                JSONObject o = new JSONObject();
                o.put("title", t.title);
                o.put("uri", t.uri);
                a.put(o);
            }
            prefs.edit().putString("tracks", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    @Override protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
