# PocketPod Android Starter

PocketPod is an early native Android music-player starter with a classic monochrome/early-iPod-inspired interface.

## Included in this starter
- Native Android project (Java + Gradle)
- Import one or multiple audio files using Android's document picker
- Save library metadata between launches
- Search imported track names
- Play, pause, previous, and next controls
- Simple monochrome library and now-playing panel

## Not implemented yet
- Video-to-audio conversion
- Embedded album artwork
- Playlists, shuffle/repeat, seek bar, background playback/service
- Full metadata parsing
- Final polish and broad device testing

## Build
This project is intended to be uploaded as a source ZIP to AndroidForge or built with Android Studio.
The build service needs internet access to download Android Gradle Plugin and dependencies.

Package: `com.pocketpod.app`
Minimum Android: API 23
Compile SDK: 35
