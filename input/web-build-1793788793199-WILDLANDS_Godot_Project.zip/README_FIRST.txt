WILDLANDS — Godot project foundation

WHAT THIS IS
This is the first real source-project foundation for WILDLANDS, an Android-first,
first-person 3D survival game. It is NOT a finished full game or an APK yet.

ENGINE
- Built for Godot 4.x
- GDScript
- Compatibility renderer (OpenGL ES 3) selected for broader Android GPU support.
- Android 9+ is the intended target, but actual device support must be tested.

WHAT IS INCLUDED
- Procedurally created test forest and ground
- First-person character controller
- Keyboard/mouse controls for desktop testing
- Touch joystick and action buttons
- Basic tree gathering and wood inventory
- Adjustable graphics panel: quality preset, shadows, render scale, FPS cap
- Graphics settings saved to user://settings.cfg

IMPORTANT CURRENT LIMITATIONS
- The world is a prototype scene made from primitive meshes, not final art.
- Axe gathering is a simple raycast interaction, not a finished weapon animation.
- Multiplayer, crafting, guns, katanas, base building, enemies, laboratories,
  saving/loading worlds, chunk streaming and final terrain are not implemented yet.
- The current mobile controls are a functional starting point and need device testing.
- A real APK requires Godot export templates and Android build tools or a supported
  Android build workflow. This archive contains source files, not a compiled APK.

HOW TO OPEN
1. Extract this ZIP.
2. Open Godot 4.
3. Choose Import.
4. Select the project.godot file in this folder.
5. Open the project and press F6 or F5 to run.
6. On desktop: WASD to move, mouse to look, Space to jump, click CHOP in the HUD.
7. On Android: export an APK after configuring Android export tools.

NEXT DEVELOPMENT SYSTEMS
1. Improve mobile input and camera controls.
2. Add real terrain and world boundaries.
3. Add rocks/mining and a proper inventory.
4. Add crafting recipes and workbench.
5. Add base building.
6. Add houses, industrial zones and underground laboratories.
7. Add wildlife and enemy AI.
8. Add multiplayer networking and authoritative server design.
9. Add final art, sound, optimization and APK testing.

Keep the project folder intact. Do not move scripts out of the scripts folder.
