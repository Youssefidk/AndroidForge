extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const HUDScript = preload("res://scripts/hud.gd")
const GatherableScript = preload("res://scripts/gatherable.gd")

var player: CharacterBody3D
var hud: CanvasLayer
var world_environment: WorldEnvironment

func _ready() -> void:
    _build_environment()
    _build_ground()
    _spawn_forest()
    _spawn_player()
    _spawn_hud()

func _build_environment() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.12, 0.23, 0.32)
    sky_mat.sky_horizon_color = Color(0.55, 0.64, 0.62)
    sky_mat.ground_bottom_color = Color(0.12, 0.16, 0.13)
    sky_mat.ground_horizon_color = Color(0.35, 0.42, 0.35)
    env.sky.sky_material = sky_mat
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.72)
    env.ambient_light_energy = 0.7
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_environment = WorldEnvironment.new()
    world_environment.environment = env
    add_child(world_environment)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.0
    sun.shadow_enabled = true
    add_child(sun)

func _build_ground() -> void:
    var ground := StaticBody3D.new()
    ground.name = "Ground"
    var mesh_instance := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(240, 240)
    mesh.subdivide_width = 40
    mesh.subdivide_depth = 40
    mesh_instance.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.19, 0.29, 0.19)
    mat.roughness = 1.0
    mesh_instance.material_override = mat
    ground.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(240, 1, 240)
    collision.shape = shape
    collision.position.y = -0.5
    ground.add_child(collision)
    add_child(ground)

func _spawn_forest() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 18473
    for i in range(85):
        var x := rng.randf_range(-95, 95)
        var z := rng.randf_range(-95, 95)
        if Vector2(x, z).length() < 9.0:
            continue
        _make_tree(Vector3(x, 0, z), rng.randf_range(0.8, 1.35))
    for i in range(30):
        var x := rng.randf_range(-90, 90)
        var z := rng.randf_range(-90, 90)
        _make_rock(Vector3(x, 0, z), rng.randf_range(0.6, 1.5))
    _make_shelter(Vector3(18, 0, -12))

func _make_tree(pos: Vector3, scale_factor: float) -> void:
    var tree := StaticBody3D.new()
    tree.set_script(GatherableScript)
    tree.resource_type = "Wood"
    tree.resource_amount = 3
    tree.position = pos
    tree.scale = Vector3.ONE * scale_factor

    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.22
    trunk_mesh.bottom_radius = 0.34
    trunk_mesh.height = 3.0
    trunk.mesh = trunk_mesh
    var bark := StandardMaterial3D.new()
    bark.albedo_color = Color(0.25, 0.16, 0.10)
    trunk.material_override = bark
    trunk.position.y = 1.5
    tree.add_child(trunk)

    var leaves := MeshInstance3D.new()
    var crown := SphereMesh.new()
    crown.radius = 1.45
    crown.height = 2.8
    leaves.mesh = crown
    var foliage := StandardMaterial3D.new()
    foliage.albedo_color = Color(0.10, 0.25, 0.12)
    foliage.roughness = 1.0
    leaves.material_override = foliage
    leaves.position.y = 3.4
    tree.add_child(leaves)

    var collision := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = 0.48
    shape.height = 3.2
    collision.shape = shape
    collision.position.y = 1.6
    tree.add_child(collision)
    add_child(tree)

func _make_rock(pos: Vector3, size_factor: float) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    var mesh_instance := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.8
    mesh.height = 1.2
    mesh_instance.mesh = mesh
    mesh_instance.scale = Vector3(size_factor, size_factor * 0.7, size_factor)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.31, 0.34, 0.32)
    mat.roughness = 1.0
    mesh_instance.material_override = mat
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.8 * size_factor
    collision.shape = shape
    collision.position.y = 0.4 * size_factor
    body.add_child(collision)
    add_child(body)

func _make_shelter(pos: Vector3) -> void:
    var building := Node3D.new()
    building.name = "Abandoned_Shelter"
    building.position = pos
    var wall_mat := StandardMaterial3D.new()
    wall_mat.albedo_color = Color(0.34, 0.31, 0.25)
    var roof_mat := StandardMaterial3D.new()
    roof_mat.albedo_color = Color(0.16, 0.18, 0.16)
    _box(building, Vector3(0, 1.5, 0), Vector3(7, 3, 6), wall_mat)
    _box(building, Vector3(0, 3.2, 0), Vector3(7.5, 0.35, 6.5), roof_mat)
    _box(building, Vector3(0, 0.9, 3.05), Vector3(1.2, 1.8, 0.2), roof_mat)
    add_child(building)

func _box(parent: Node, pos: Vector3, size: Vector3, material: Material) -> void:
    var instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    parent.add_child(instance)

func _spawn_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PlayerScript)
    player.position = Vector3(0, 2, 0)
    add_child(player)

func _spawn_hud() -> void:
    hud = CanvasLayer.new()
    hud.set_script(HUDScript)
    hud.world = self
    hud.player = player
    add_child(hud)
