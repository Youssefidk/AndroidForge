extends StaticBody3D

@export var resource_type := "Wood"
@export var resource_amount := 3
@export var hits_required := 3
var hits_taken := 0
var depleted := false

func gather() -> Dictionary:
    if depleted:
        return {}
    hits_taken += 1
    if hits_taken >= hits_required:
        depleted = true
        queue_free()
    return {"type": resource_type, "amount": resource_amount}
