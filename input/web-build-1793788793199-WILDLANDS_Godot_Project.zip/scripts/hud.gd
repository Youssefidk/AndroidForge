extends CanvasLayer

var world: Node3D
var player: CharacterBody3D
var info_label: Label
var inventory_label: Label
var menu_panel: PanelContainer
var joystick_origin := Vector2.ZERO
var joystick_touch := -1
var look_touch := -1
var joystick_value := Vector2.ZERO
var move_touch_id := -1
var settings := {"quality": "Medium", "fps": 60, "shadows": true, "render_scale": 1.0}

func _ready() -> void:
    _make_hud()
    _load_settings()
    _apply_settings()

func _make_hud() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root)

    info_label = Label.new()
    info_label.position = Vector2(24, 18)
    info_label.add_theme_font_size_override("font_size", 22)
    info_label.text = "WILDLANDS  |  FIELD TEST"
    root.add_child(info_label)

    inventory_label = Label.new()
    inventory_label.position = Vector2(24, 52)
    inventory_label.add_theme_font_size_override("font_size", 18)
    inventory_label.text = "WOOD  0     STONE  0"
    root.add_child(inventory_label)

    var axe_button := _make_button(root, "CHOP", Vector2(-150, -155), Vector2(112, 58), Vector2(1, 1))
    axe_button.pressed.connect(_on_axe_pressed)
    var jump_button := _make_button(root, "JUMP", Vector2(-150, -85), Vector2(112, 58), Vector2(1, 1))
    jump_button.pressed.connect(func(): player.request_jump())
    var sprint_button := _make_button(root, "RUN", Vector2(-280, -85), Vector2(112, 58), Vector2(1, 1))
    sprint_button.button_down.connect(func(): player.set_sprint(true))
    sprint_button.button_up.connect(func(): player.set_sprint(false))

    var settings_button := _make_button(root, "SETTINGS", Vector2(-150, 18), Vector2(112, 48), Vector2(1, 0))
    settings_button.pressed.connect(_toggle_settings)

    _create_settings_panel(root)

    var hint := Label.new()
    hint.text = "LEFT: MOVE     RIGHT: LOOK     CHOP: GATHER WOOD"
    hint.position = Vector2(24, -34)
    hint.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    hint.add_theme_font_size_override("font_size", 14)
    root.add_child(hint)

func _make_button(parent: Control, text_value: String, offset: Vector2, size_value: Vector2, anchor: Vector2) -> Button:
    var button := Button.new()
    button.text = text_value
    button.size = size_value
    button.anchor_left = anchor.x
    button.anchor_right = anchor.x
    button.anchor_top = anchor.y
    button.anchor_bottom = anchor.y
    button.offset_left = offset.x
    button.offset_right = offset.x + size_value.x
    button.offset_top = offset.y
    button.offset_bottom = offset.y + size_value.y
    button.add_theme_font_size_override("font_size", 17)
    parent.add_child(button)
    return button

func _create_settings_panel(parent: Control) -> void:
    menu_panel = PanelContainer.new()
    menu_panel.visible = false
    menu_panel.position = Vector2(24, 110)
    menu_panel.size = Vector2(330, 430)
    parent.add_child(menu_panel)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    menu_panel.add_child(box)

    var title := Label.new()
    title.text = "GRAPHICS SETTINGS"
    title.add_theme_font_size_override("font_size", 22)
    box.add_child(title)

    var quality := OptionButton.new()
    quality.add_item("Low")
    quality.add_item("Medium")
    quality.add_item("High")
    quality.add_item("Ultra")
    quality.selected = 1
    quality.item_selected.connect(_on_quality_selected)
    box.add_child(_labeled("Quality preset", quality))

    var shadows := CheckButton.new()
    shadows.text = "Dynamic shadows"
    shadows.button_pressed = true
    shadows.toggled.connect(_on_shadows_toggled)
    box.add_child(shadows)

    var scale_slider := HSlider.new()
    scale_slider.min_value = 0.65
    scale_slider.max_value = 1.0
    scale_slider.step = 0.05
    scale_slider.value = 1.0
    scale_slider.value_changed.connect(_on_scale_changed)
    box.add_child(_labeled("3D render scale", scale_slider))

    var fps := OptionButton.new()
    fps.add_item("30 FPS")
    fps.add_item("45 FPS")
    fps.add_item("60 FPS")
    fps.selected = 2
    fps.item_selected.connect(_on_fps_selected)
    box.add_child(_labeled("Frame limit", fps))

    var close := Button.new()
    close.text = "CLOSE"
    close.pressed.connect(_toggle_settings)
    box.add_child(close)

func _labeled(label_text: String, control: Control) -> Control:
    var wrapper := VBoxContainer.new()
    var label := Label.new()
    label.text = label_text
    wrapper.add_child(label)
    wrapper.add_child(control)
    return wrapper

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var screen := get_viewport().get_visible_rect().size
        if event.pressed:
            if event.position.x < screen.x * 0.42 and joystick_touch == -1:
                joystick_touch = event.index
                joystick_origin = event.position
                _update_joystick(event.position)
        elif event.index == joystick_touch:
            joystick_touch = -1
            joystick_value = Vector2.ZERO
            player.set_mobile_move(Vector2.ZERO)
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        _update_joystick(event.position)

func _update_joystick(pos: Vector2) -> void:
    var delta: Vector2 = (pos - joystick_origin) / 75.0
    joystick_value = Vector2(delta.x, delta.y).limit_length(1.0)
    player.set_mobile_move(joystick_value)

func _on_axe_pressed() -> void:
    player.use_axe()
    inventory_label.text = player.get_inventory_text()

func _toggle_settings() -> void:
    menu_panel.visible = not menu_panel.visible

func _on_quality_selected(index: int) -> void:
    settings.quality = ["Low", "Medium", "High", "Ultra"][index]
    match settings.quality:
        "Low":
            settings.render_scale = 0.7
            settings.shadows = false
        "Medium":
            settings.render_scale = 0.85
            settings.shadows = false
        "High":
            settings.render_scale = 1.0
            settings.shadows = true
        "Ultra":
            settings.render_scale = 1.0
            settings.shadows = true
    _apply_settings()
    _save_settings()

func _on_shadows_toggled(value: bool) -> void:
    settings.shadows = value
    _apply_settings()
    _save_settings()

func _on_scale_changed(value: float) -> void:
    settings.render_scale = value
    _apply_settings()
    _save_settings()

func _on_fps_selected(index: int) -> void:
    settings.fps = [30, 45, 60][index]
    Engine.max_fps = settings.fps
    _save_settings()

func _apply_settings() -> void:
    get_viewport().scaling_3d_scale = float(settings.render_scale)
    if world and world.world_environment and world.world_environment.environment:
        world.world_environment.environment.tonemap_exposure = 1.0
    if world:
        for node in world.get_children():
            if node is DirectionalLight3D:
                node.shadow_enabled = bool(settings.shadows)

func _save_settings() -> void:
    var config := ConfigFile.new()
    for key in settings:
        config.set_value("graphics", key, settings[key])
    config.save("user://settings.cfg")

func _load_settings() -> void:
    var config := ConfigFile.new()
    if config.load("user://settings.cfg") == OK:
        for key in settings:
            settings[key] = config.get_value("graphics", key, settings[key])
    Engine.max_fps = int(settings.fps)

