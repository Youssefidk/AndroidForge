extends CharacterBody3D

signal resource_gathered(resource_name: String, amount: int)

@export var walk_speed := 4.6
@export var sprint_speed := 7.0
@export var jump_velocity := 4.5
@export var look_sensitivity := 0.003
@export var touch_look_sensitivity := 0.004

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var camera_pivot: Node3D
var camera: Camera3D
var joystick_vector := Vector2.ZERO
var touch_look_delta := Vector2.ZERO
var jump_requested := false
var sprinting := false
var inventory := {"Wood": 0, "Stone": 0}

func _ready() -> void:
    _build_camera()
    if not OS.has_feature("mobile"):
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_camera() -> void:
    var body_collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.35
    capsule.height = 1.8
    body_collision.shape = capsule
    body_collision.position.y = 0.9
    add_child(body_collision)

    camera_pivot = Node3D.new()
    camera_pivot.position.y = 1.62
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 78.0
    camera_pivot.add_child(camera)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _look(event.relative)
    elif event is InputEventScreenDrag:
        if event.position.x > get_viewport().get_visible_rect().size.x * 0.38:
            _look(event.relative * 1.2)

func _look(delta: Vector2) -> void:
    rotate_y(-delta.x * look_sensitivity)
    camera_pivot.rotation.x = clamp(camera_pivot.rotation.x - delta.y * look_sensitivity, -1.45, 1.45)

func set_mobile_move(value: Vector2) -> void:
    joystick_vector = value.limit_length(1.0)

func request_jump() -> void:
    jump_requested = true

func set_sprint(value: bool) -> void:
    sprinting = value

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif jump_requested:
        velocity.y = jump_velocity
    jump_requested = false

    var input_vector := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if joystick_vector.length() > 0.08:
        input_vector = joystick_vector
    var direction := (transform.basis * Vector3(input_vector.x, 0, input_vector.y)).normalized()
    var speed := sprint_speed if (sprinting or Input.is_action_pressed("sprint")) else walk_speed
    if direction:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
    else:
        velocity.x = move_toward(velocity.x, 0, speed * 4.0 * delta)
        velocity.z = move_toward(velocity.z, 0, speed * 4.0 * delta)
    if Input.is_action_just_pressed("jump"):
        request_jump()
    move_and_slide()

func use_axe() -> void:
    var space_state := get_world_3d().direct_space_state
    var query := PhysicsRayQueryParameters3D.create(
        camera.global_position,
        camera.global_position + (-camera.global_transform.basis.z * 3.0)
    )
    query.exclude = [self]
    var result := space_state.intersect_ray(query)
    if result and result.collider.has_method("gather"):
        var gathered: Dictionary = result.collider.gather()
        if not gathered.is_empty():
            var resource := String(gathered.get("type", "Wood"))
            var amount := int(gathered.get("amount", 1))
            inventory[resource] = int(inventory.get(resource, 0)) + amount
            resource_gathered.emit(resource, amount)

func get_inventory_text() -> String:
    return "WOOD  %d     STONE  %d" % [inventory.get("Wood", 0), inventory.get("Stone", 0)]
